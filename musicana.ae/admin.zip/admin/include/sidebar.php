    <div class="sidebar" data-color="blue" data-image="assets/img/sidebar-5.jpg">    
    
    <!--   you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple" -->
    
    
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                   لوحة التحكم
                </a>
            </div>
                       
            <ul class="nav">
            	<li>
                    <a href="stats.php">
                        <i class="pe-7s-home"></i> 
                        <p>الرئيسية</p>
                    </a>
                </li> 
                <li>
                    <a href="inbox.php">
                        <i class="pe-7s-mail-open-file"></i> 
                        <p>الرسائل <span class='badge' style='background:#d10505'><?= $new->count?></span></p>
                    </a>        
                </li>
                <li>
                    <a href="add_owner.php">
                        <i class="pe-7s-plus"></i> 
                        <p>إضافة مالك</p>
                    </a>
                </li> 
                <li>
                    <a href="owners.php">
                        <i class="pe-7s-news-paper"></i> 
                        <p>عرض المالكين</p>
                    </a>        
                </li>
                <li>
                    <a href="add_singer.php">
                        <i class="pe-7s-plus"></i> 
                        <p>إضافة فنان</p>
                    </a>
                </li> 
                <li>
                    <a href="singers.php">
                        <i class="pe-7s-news-paper"></i> 
                        <p>عرض المطربين</p>
                    </a>        
                </li>
                <li>
                    <a href="female-singers.php">
                        <i class="pe-7s-news-paper"></i> 
                        <p>عرض المطربات</p>
                    </a>        
                </li>
                <li>
                    <a href="dancers.php">
                        <i class="pe-7s-news-paper"></i> 
                        <p>عرض الراقصات</p>
                    </a>        
                </li>
                <li>
                    <a href="main_sched.php">
                        <i class="fa fa-table"></i> 
                        <p>جدول المواعيد</p>
                    </a>        
                </li>
                  
              
                
            </ul> 
    	</div>
    </div>