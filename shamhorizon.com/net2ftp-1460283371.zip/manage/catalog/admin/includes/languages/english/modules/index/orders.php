<?php
/*
  $Id: orders.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

define('ADMIN_INDEX_ORDERS_TITLE', 'Orders');
define('ADMIN_INDEX_ORDERS_TOTAL', 'Total');
define('ADMIN_INDEX_ORDERS_DATE', 'Date');
define('ADMIN_INDEX_ORDERS_STATUS', 'Status');
?>
