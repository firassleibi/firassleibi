<?php
/*
  $Id: tax_classes.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Tipos de Impuesto');

define('TABLE_HEADING_TAX_CLASSES', 'Tipos de Impuesto');
define('TABLE_HEADING_ACTION', 'Acci&oacute;n');

define('TEXT_INFO_EDIT_INTRO', 'Haga los cambios necesarios');
define('TEXT_INFO_CLASS_TITLE', 'Nombre del Impuesto:');
define('TEXT_INFO_CLASS_DESCRIPTION', 'Descripci&oacute;n:');
define('TEXT_INFO_DATE_ADDED', 'Creado:');
define('TEXT_INFO_LAST_MODIFIED', 'Modificado:');
define('TEXT_INFO_INSERT_INTRO', 'Introduzca los datos del nuevo tipo de impuesto');
define('TEXT_INFO_DELETE_INTRO', 'Seguro que desea eliminar este tipo de impuesto?');
define('TEXT_INFO_HEADING_NEW_TAX_CLASS', 'Nuevo Tipo de Impuesto');
define('TEXT_INFO_HEADING_EDIT_TAX_CLASS', 'Editar Tipo de Impuesto');
define('TEXT_INFO_HEADING_DELETE_TAX_CLASS', 'Eliminar Tipo de Impuesto');
?>