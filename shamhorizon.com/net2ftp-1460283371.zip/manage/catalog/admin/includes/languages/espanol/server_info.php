<?php
/*
  $Id: server_info.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Informaci&oacute;n del Servidor');

define('TITLE_SERVER_HOST', 'Nombre del Servidor:');
define('TITLE_SERVER_OS', 'Sistema Operativo del Servidor:');
define('TITLE_SERVER_DATE', 'Fecha en el Servidor:');
define('TITLE_SERVER_UP_TIME', 'Encendido desde:');
define('TITLE_HTTP_SERVER', 'Servidor HTTP:');
define('TITLE_PHP_VERSION', 'Version PHP:');
define('TITLE_ZEND_VERSION', 'Zend:');
define('TITLE_DATABASE_HOST', 'Servidor de Base de Datos:');
define('TITLE_DATABASE', 'Base de Datos:');
define('TITLE_DATABASE_DATE', 'Fecha de la Base de Datos:');
?>
