CREATE DATABASE IF NOT EXISTS fahad_kh;

USE fahad_kh;

