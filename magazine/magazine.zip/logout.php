<?php
include("include/phrases.php");
include("include/db.php");
include("include/functions.php");
    logout();
?>