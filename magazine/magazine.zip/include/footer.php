<div class="copy">
    <p> <?= COPYWRITE?> </p>
</div>