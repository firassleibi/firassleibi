<?php
    $server = LOCAL_HOST;
    $username = DB_USER;
    $password = DB_PASSWORD;
    $db = DB_NAME;
    $con=mysqli_connect($server,$username,$password,$db);
?>