<?php
    session_start();
    function checkAdminPassword($username,$password){
        global $con;
        $result=false;
        $stmt = $con->prepare("SELECT password FROM settings WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($stored_password);
        if($stmt->num_rows>0){
            $stmt->fetch();
            if (password_verify($password, $stored_password))
                $result=true;
        }
        return $result;
    }
    function setAdminPassword($password){
        global $con;
        $password=password_hash($password, PASSWORD_BCRYPT);
        $stmt = $con->prepare("UPDATE settings set password=? WHERE id = 1");
        $stmt->bind_param("s", $password);
        $stmt->execute();
    }
    function setSession(){
        $_SESSION['loggedin']=true;

    }
    function checkSession(){
        if(!isset($_SESSION['loggedin']))
            header("location: signin.php");
    }
    function getAdminUsername(){
        global $con;
        $stmt = $con->prepare("SELECT username FROM settings WHERE id = 1");
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($username);
        if($stmt->num_rows>0){
            $stmt->fetch();
        }
        return $username;
    }
    function logout(){
        session_destroy();
        header("location: index.php");
    }
    function uploadBook($file,$filename){
        $target_dir = "books/";
        $target_file = $target_dir . $filename.".pdf";
        $uploadOk = 1;
        $imageFileType = pathinfo($file["name"],PATHINFO_EXTENSION);

// Check if file already exists
        if (file_exists($target_file)) {
            $error= "Sorry, Magazine name already exists.";
            $uploadOk = 0;
        }

// Allow certain file formats
        if($imageFileType != "pdf" ) {
            $error= "Sorry, only PDF files are allowed.";
            $uploadOk = 0;
        }
// Check if $uploadOk is set to 0 by an error
        if ($uploadOk != 0) {
            if (move_uploaded_file($file["tmp_name"], $target_file)) {
                $error="none";
                $bookid=insertBook($filename);
                header("location: convert.php?id=$bookid");
            } else {
                $error= "Sorry, there was an error uploading the file, Please try again.";
            }
        }
        return $error;
        }

    function insertBook($bookname){
        global $con;
        $stmt = $con->prepare("INSERT into books set bookname=?");
        $stmt->bind_param("s", $bookname);
        $stmt->execute();
        return $stmt->insert_id;
    }
    function getBookPages($id){
        global $con;
		$pages="none";
        $stmt = $con->prepare("SELECT pages FROM books WHERE id = ?");
		$stmt->bind_param("s", $id);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($pages);
        if($stmt->num_rows>0){
            $stmt->fetch();
        }
        return $pages;
    }
	function getBookName($id){
        global $con;
		$pages="none";
        $stmt = $con->prepare("SELECT bookname FROM books WHERE id = ?");
		$stmt->bind_param("s", $id);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($bookname);
        if($stmt->num_rows>0){
            $stmt->fetch();
        }
        return $bookname;
    }
	function setPages($id,$pages){
        global $con;
        $stmt = $con->prepare("UPDATE books set pages=? WHERE id = ?");
        $stmt->bind_param("ss", $id, $pages);
        $stmt->execute();
    }

?>