<?php
    define("TITLE","Title",TRUE);
    define("COPYWRITE","© 2016. All Rights Reserved ",TRUE);
    //Menus
    define("DASHBOARD","Dashboard",TRUE);
    define("ADDMAGAZINE","Add Magazine",TRUE);
    // DB Variables
    define("LOCAL_HOST","localhost");
    define("DB_USER","root");
    define("DB_PASSWORD","");
    define("DB_NAME","magazine");
?>