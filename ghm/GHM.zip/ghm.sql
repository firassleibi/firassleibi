-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2017 at 02:06 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ghm`
--

-- --------------------------------------------------------

--
-- Table structure for table `queries`
--

CREATE TABLE IF NOT EXISTS `queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `text_area` varchar(400) NOT NULL,
  `radio_selected` varchar(50) NOT NULL,
  `check_boxs` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `queries`
--

INSERT INTO `queries` (`id`, `name`, `email`, `text_area`, `radio_selected`, `check_boxs`) VALUES
(1, 'f', 'firas@doodleworldwide.com', 'fdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.com', 'yes', 'option1 option2 '),
(2, 'f', 'firas@doodleworldwide.com', 'fdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.comfdfdfd@dd.com', 'yes', 'option1 option2 ');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
