<?php
    $server = "localhost";
    $username = "firassle_ghm";
    $password = "hello/123";
    $db = "firassle_ghm";
    $con=mysqli_connect($server,$username,$password,$db);
?>